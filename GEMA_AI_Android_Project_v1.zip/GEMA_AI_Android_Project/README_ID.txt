GEMA AI - Proyek Android

Isi:
- Aplikasi Android WebView offline.
- HTML GEMA AI v1.3 di app/src/main/assets/index.html.
- Penyimpanan data lokal melalui WebView DOM Storage/localStorage.
- Pemilih file Android untuk unggah foto profil; crop interaktif tetap di HTML.

Cara build:
1. Ekstrak folder proyek.
2. Buka folder GEMA_AI_Android_Project melalui Android Studio.
3. Tunggu Gradle Sync selesai (memerlukan koneksi untuk mengunduh Android Gradle Plugin dan SDK bila belum tersedia).
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug akan muncul di app/build/outputs/apk/debug/app-debug.apk.

Catatan:
- Ini adalah proyek sumber Android, bukan file APK yang sudah dikompilasi.
- Aplikasi tidak meminta internet permission dan tidak menggunakan server/cloud.
- Jangan hapus data aplikasi/uninstall jika ingin mempertahankan data lokal.
